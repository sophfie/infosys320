﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PracticeTest3 : MonoBehaviour
{

    public GameObject myPrefab;

    // Use this for initialization
    void Start()
    {

        int totalCubes = 30;  
        //float totalDistance = 2.9f;

        // SIN DISTRO
        for (int i = 0; i < totalCubes; i++)
        {

            float x = Random.Range(0f, 5f);
            float y = Random.Range(0f, 10f);
            float z = Random.Range(0f, 5f);

            var newCube = (GameObject)Instantiate(myPrefab, new Vector3(x, y, z), Quaternion.identity);

            newCube.GetComponent<CubeScript>().SetSize(1.0f);

  

        };



    }

    // Update is called once per frame
    void Update()
    {

    }
}
