﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeScript : MonoBehaviour {

    public float rotateSpeed = 1.0f;
    public Vector3 spinSpeed = Vector3.zero;
    public Vector3 spinAxis = new Vector3(0,1,0);

	// Use this for initialization
	void Start () {
        spinSpeed = new Vector3(Random.value, Random.value, Random.value);
        spinAxis = Vector3.up;
        spinAxis.x = (Random.value - Random.value) *.1f;
		
	}

    // turn blue function
    void TurnBlue() {
        GetComponent<Renderer>().material.color = Color.blue;
    }

    // make time = i
    public void CubeSeconds(int time) {
        StartCoroutine(MyCoroutine(time));
    }

    public void SetSize(float size)
    {
        this.transform.localScale = new Vector3(size, size, size);
    }

    // Update is called once per frame
    void Update () {
        this.transform.Rotate(spinSpeed); //when using decimals, put f to indicate its a floating point
        this.transform.RotateAround(Vector3.zero, spinAxis, rotateSpeed);
	}

    IEnumerator MyCoroutine(int time)
    {
        //This is a coroutine

        yield return new WaitForSeconds(time);   //Wait i seconds

        TurnBlue();
    }
}

// DECIMALS
// when using decimals, put f to indicate its a floating point

// VECTOR 3
// Vector 3 = collection of 3 values x y z

// VECTOR 3 ZERO
// new Vector3(0,0,0); === Vector3.zero;


// PUBLIC VARIABLES
//public because we want to use it again multiple times (anywhere can reference it)

// RANDOM VALUE
//random Random.value gives a random decimal from 0-1.

// RANDOM RANGE (INCLUSIVE)
// Random.Range(0f, 5f);

// RANDOM VALUE BETWEEN -1 and 1 
// Random.value - Random.value e.g. 0-1 = -1. 1-0 = 1.

// SHRINK VALUE
// *.1 keeps it small

// MOVE POSITION
//  this.transform.position = new Vector3(0, 5, 3);

// CHANGE COLOR
// newCube.GetComponent<Renderer>().material.color = Color.blue;
