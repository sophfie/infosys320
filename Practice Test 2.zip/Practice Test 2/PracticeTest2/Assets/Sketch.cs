﻿// PRACTICE TEST SBUR452

using UnityEngine;
using Pathfinding.Serialization.JsonFx; //make sure you to this line

public class Sketch : MonoBehaviour
{
    public GameObject myPrefab;
    public string _WebsiteURL = "http://chronospatial.azurewebsites.net/tables/Mountain?zumo-api-version=2.0.0";    // data url 1
    void Start()
    {
        http://chronospatial.azurewebsites.net/tables/Mountain?zumo-api-version=2.0.0    // data url 2

        string jsonResponse = Request.GET(_WebsiteURL);

        if (string.IsNullOrEmpty(jsonResponse))
        {
            return;
        }

        //Thing[] thingsarray = JsonReader.Deserialize<Thing[]>(jsonResponse);
        Mountain[] mountainsArray = JsonReader.Deserialize<Mountain[]>(jsonResponse);

        int i = 0;
        int length = mountainsArray.Length;

        //foreach (Thing thing in thingssArray)
        foreach (Mountain mountain in mountainsArray)
        {
            
                float perc = i / (float)length;
                float sin = Mathf.Sin(perc * Mathf.PI / 2);

                //pull X, Y & Z from the data tables and into a variable

                //float x = thingssArray[i].number
                float x = mountainsArray[i].X;
                float y = mountainsArray[i].Y;
                float z = mountainsArray[i].Z;

                //set posiiton, rotation, text and size based on data in array
                var newCube = (GameObject)Instantiate(myPrefab, new Vector3(x, y, z), Quaternion.identity);

                //newCube.GetComponent<CubeScript>().SetSize(thingsArray[i].Size * 0.1f); changes size              

                //stop spinning
                newCube.GetComponent<CubeScript>().rotateSpeed = 0;

                //set text
                newCube.GetComponentInChildren<TextMesh>().text = mountainsArray[i].MountainName;
            
            i++;



            //----------------------
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
}
