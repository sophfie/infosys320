﻿//PRACTICE TEST SBUR452

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//class Thing
class Mountain
{
    // NOTE TO SELF (int/string)
    public int MountainID { get; set; }
    public string MountainName { get; set; }
    public int X { get; set; }
    public int Y { get; set; }
    public int Z { get; set; }
    public int Size { get; set; }
    public string Symbol { get; set; }
}
